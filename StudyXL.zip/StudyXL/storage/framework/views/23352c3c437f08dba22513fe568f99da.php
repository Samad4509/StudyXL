<?php echo e($slot); ?>

<?php /**PATH D:\orbit\xampp\htdocs\New folder\StudyXL\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>