<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Reset Password</title>
</head>
<body>
    <h2>Reset  Password</h2>
    <?php if($errors->any()): ?>
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><?php echo e($error); ?></li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <li><?php echo e(Session::get('error')); ?></li>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <li><?php echo e(Session::get('success')); ?></li>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.reset_password_submit')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo e($token); ?>">
        <input type="hidden" name="email" value="<?php echo e($email); ?>">
        <input type="password" name="password" placeholder="password"><br>
         <input type="password" name="password_confirmation" placeholder="confirm password"><br>
        <button type="submit">Submit</button>
    </form>
   
</body>
</html><?php /**PATH D:\orbit\xampp\htdocs\studyxl\resources\views/admin/reset_password.blade.php ENDPATH**/ ?>