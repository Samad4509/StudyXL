<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        th { background-color: #f4f4f4; }
        .btn { padding: 6px 12px; border: none; cursor: pointer; text-decoration: none; }
        .btn-approve { background: green; color: #fff; }
        .btn-reject { background: red; color: #fff; }
    </style>
</head>
<body>
    <h2>Admin Dashboard</h2>
    <p>Welcome, <?php echo e(Auth::guard('admin')->user()->name); ?></p>
    <a href="<?php echo e(route('admin.logout')); ?>">Logout</a>

    <h3>Agent List</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Approval</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($agent->id); ?></td>
                    <td><?php echo e($agent->name); ?></td>
                    <td><?php echo e($agent->email); ?></td>
                    <td><?php echo e($agent->is_approved ? '✅ Approved' : '⏳ Pending'); ?></td>
                    <td><?php echo e($agent->status); ?></td>
                    <td>
                        <?php if(!$agent->is_approved): ?>
                            <a href="<?php echo e(route('admin.approve.agent', $agent->id)); ?>" class="btn btn-approve">Approve</a>
                        <?php else: ?>
                            <?php if($agent->status === 'active'): ?>
                                <a href="<?php echo e(route('admin.deactivate.agent', $agent->id)); ?>" class="btn btn-reject">Deactivate</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('admin.activate.agent', $agent->id)); ?>" class="btn btn-approve">Activate</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\orbit\xampp\htdocs\New folder\StudyXL\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>