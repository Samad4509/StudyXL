<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Forget Password</title>
</head>
<body>
    <h2>Forget Password</h2>
    <?php if($errors->any()): ?>
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><?php echo e($error); ?></li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <li><?php echo e(Session::get('error')); ?></li>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <li><?php echo e(Session::get('success')); ?></li>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.forget_password_submit')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="email" placeholder="Eamil"><br>
        <button type="submit">Forget</button>

    </form>
    <a href="<?php echo e(route('admin.login')); ?>">Back To Login Page</a>
</body>
</html><?php /**PATH D:\orbit\xampp\htdocs\studyxl\resources\views/admin/forget-password.blade.php ENDPATH**/ ?>